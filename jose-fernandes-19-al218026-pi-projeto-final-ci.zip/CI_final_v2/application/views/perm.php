<h1>Não tens permissões para entrar nesta página</h1>
<p><a href={voltar}>Voltar</a></p>
