<p>{form_error}</p>
<p>{form_sucess}</p>
<h1>{title}</h1>
	<p>Nome: {nome}</p>
	<p>Nif: {nif}</p>
	<p>Nib: {nib}</p>
	<p>Especialidade: {especialidade}</p>
	<p>Morada: {morada}</p>
	<p>Username: {username}</p>
	<p>Email: {email}</p>
<a href="{back}">Voltar:</a>
