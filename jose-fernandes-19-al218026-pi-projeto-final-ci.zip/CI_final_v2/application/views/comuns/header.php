<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="description" content="Site da Epcc">
	<meta name="author" content="Alunos programacao">
	<link rel="stylesheet" href="<?echo base_url()?>css/estilo.css">
	<title>{title}</title>
</head>
	</html>
	<body>
