<ul class="nav menu-nav">
	<li>
		<a class="active" href="{home}" >Home</a>
	</li>
	{menu}
	<li>
		<a href="{url}">{display}</a>
	</li>
	{/menu}
	<li>
		<li style="float:right"><a class="active" href="{urlLogin}">{urlBtn}</a></li>
	</li>
</ul>
