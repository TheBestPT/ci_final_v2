<h1>Adcionar enfermeiros a consulta</h1>
<table>
	<thead>
	<tr>
		<th>Nome</th>
		<th>Edição</th>
	</tr>
	</thead>
	<tbody>
	{items}
	<tr>
		<td>{nome}</td>
		<td><a href="{add}">Adcionar</a>
			&nbsp;&nbsp;<a href="{del}">Del</a></td>
	</tr>
	{/items}
	</tbody>
</table>
<h1>Enfermeiros já adicionados</h1>
<p><b>{nome}</b></p>
<p><a href="{voltar}">Voltar</a></p>
