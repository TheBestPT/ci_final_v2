<center><h1>Clínica Privada Francisco Fernandes</h1>
	<p>Fazemos todo o tipo de cirurgias e partes de enfermagem etc... Para consultas etc é fazer uso do WebSite. Seja Bem Vindo!!!!!!!</p></center>
