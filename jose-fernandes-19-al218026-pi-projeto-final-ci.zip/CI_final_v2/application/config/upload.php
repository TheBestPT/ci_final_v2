<?php 
// permissoes de escrita sobre esta pasta
$config['upload_path'] = 'uploads/';
// tem premissoes para a raiz do projeto
$config['allowed_types'] = 'gif|jpg|png|jpeg|pdf';// mime
$config['max_size'] = '4096';// kb 4096 <=> 4mb
$config['max_width'] = '2048';// px
$config['max_height'] = '1536';// px
?>
